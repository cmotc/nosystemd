---------------------------------------------------------------------------
-- @author Julien Danjou &lt;julien@danjou.info&gt;
-- @copyright 2008 Julien Danjou
-- @release v3.5.6
---------------------------------------------------------------------------

--- Suits for awful

return
{
    max = require("awful.layout.suit.max");
    tile = require("awful.layout.suit.tile");
    fair = require("awful.layout.suit.fair");
    floating = require("awful.layout.suit.floating");
    magnifier = require("awful.layout.suit.magnifier");
    spiral = require("awful.layout.suit.spiral");
}

# fireblock
a shell script which emits blacklist rules for blocking ieee1394 attacks.
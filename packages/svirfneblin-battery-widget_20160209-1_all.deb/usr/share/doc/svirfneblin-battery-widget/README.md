# svirfneblin-battery-widget
battery widget for awesome wm

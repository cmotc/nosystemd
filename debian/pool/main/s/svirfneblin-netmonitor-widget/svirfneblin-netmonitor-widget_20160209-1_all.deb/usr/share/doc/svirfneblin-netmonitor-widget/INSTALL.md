Installing
==========

Installing this on Debian or Ubuntu is easiest right now. Just build and install
the .deb, and add the widget to your AwesomeWM configuration. To install it this
way first download the source code, unzip it, and run debian.sh. Then move into
the parent directory and run sudo dpkg -i svirfneblin-netmonitor-widget*.deb.

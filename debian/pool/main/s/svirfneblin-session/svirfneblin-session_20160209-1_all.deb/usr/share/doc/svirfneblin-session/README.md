# svirfneblin-session
Session for my AwesomeWM+LightDM+GTK desktop.

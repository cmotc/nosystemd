debian-awesome-gnome
=======================

Scripts and Configuration for Gnome Integration with Awesome for Debian
based on the work from Arch (https://github.com/nekonyuu/archlinux-awesome-gnome)[https://github.com/nekonyuu/archlinux-awesome-gnome]